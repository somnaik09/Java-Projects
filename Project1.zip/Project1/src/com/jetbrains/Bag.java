package com.jetbrains;

/*
 * Defines a class where implementation of ADT bag using array data structure is taken place
 * @author Som Naik
 * @version 1.0
 */


public class Bag implements BagInterface {

    //Object array that stores groceries
    private Object[] data;

    /*
    *Constructs new Bag object and initializes array
     */
    public Bag(){
        this.data = new Object[100];
    }

    /*
    * Returns reference to object array associated with respective object
    * @return A reference to an object array
     */

public Object[] getData(){
        return this.data;
}


    /*
     *determines whether array is empty
     * @return A boolean value whether list is empty or not
     */

    public boolean isEmpty() {

        //scrolls through array to verify emptiness
        for(int i = 0; i < 100; i++){
            if(this.data[i] != null)
                return false;
        }
        return true;
    }

    /*
     * Determines number of items in array
     * @return An integer specifying the number of items in array
     */

    public int size() {

        //finds first null value to determine true size
        int i = 0;
        while(this.data[i] != null && i < 100){
            i++;
            if(this.data[99] != null)
                return 100;
        }
        return i;

    }

    /*
     * Adds data point to end of array.
     * @param data A reference to the data point added
     * @throws BagException If bag is full.
     */

    public void insert(Object data) throws BagException {

        //BagException When array is full.
        if(this.data[99] != null){
            throw new BagException("Bag is Full! Cannot add.");
        }

        //finding first null value
        int fnull = 0;
        while(this.data[fnull] != null){
            fnull++;
        }

        //inserting object
        this.data[fnull] = data;


    }

    /*
     * removes last data point in the array
     * @throws BagException If bag is empty
     */

    public void removeLast() throws BagException {

        //BagException When bag is empty
        if(this.isEmpty() == true){
            throw new BagException("Bag is Empty! Cannot remove.");
        }

        //Removes last item for full bag since there is no first null for full bag
        if(this.data[99] != null){
            this.data[99] = null;
            return;
        }

        //Otherwise, finds index of first null
        int fnull = 0;
        while(this.data[fnull] != null){
            fnull++;
        }

        //removes last item
        this.data[fnull - 1] = null;


    }

    /*
     * Removes all data points in the array.
     */


    public void makeEmpty() {

        //Assigns reference to a new empty object array
        this.data = new Object[100];

    }


    /*
     * Returns data point given index
     * @return object occurring at given index
     * @param index Integer specifying position of data
     * @throws ListIndexOutOfBoundsException If index < 0 or index >= size()
     * @throws BagException If bag is empty. size() = 0
     */

    public Object get(int index) throws ListIndexOutOfBoundsException, BagException {

        //BagException When bag is empty
        if(this.isEmpty())
            throw new BagException("Bag is Empty! Cannot retrieve item");

        //ListIndexOutOfBoundsException Index out of bounds of range of valid objects
        if(index < 0 || index >= this.size()){
            throw new ListIndexOutOfBoundsException("Index out of bounds!");
        }

            System.out.println("Grocery at index " + index + ": " + this.data[index]);

        //return object
        return this.data[index];

    }

    /*
     * Retrieves first index of specified Object in the array.
     * @return integer specifying index of given object
     * @param object A reference value for object you want to search
     * @throws BagException If bag is empty.
     * Locally handles exception when @param (object) is not a String.
     */

    public int get(Object object) throws BagException {

        //BagException Bag is empty
        if(this.isEmpty())
            throw new BagException("Bag is Empty! Cannot retrieve item index");

        //Finding index of first null value in array
        int fnull = 0;
        while(this.data[fnull] != null){   //Finding index of first null value in array
            if(this.data[99] != null){
                fnull = 100;
                break;
            }
            fnull++;
        }


        int index = 0;

        //Handles Exception where @param object is not castable to a String
        try{
            String st1 = (String)object;
        }catch (Exception e){
            System.out.println("Enter a valid grocery name! (String)");
            return -1;
        }

        String st1 = (String)object;

        //Scrolls through array from index 0 to index (first null) to find index of requested object
        for(int i = 0; i < fnull; i++){

            String st = (String)this.data[i];

            //Comparing each data point in array to object specified in parameter of method
            if(st.compareToIgnoreCase(st1) == 0){
                index = i;
                break;
            }else
                index = -1;

        }


        // Locates index and returns with a statement or returns -1
        if(index == -1)
            System.out.println("Grocery " + object + " is not in the Bag!" +"\n^^^index: " + index);
        else
            System.out.print("Grocery " + object + " is located at index: " + index);
        return index;

    }

    /*
     * Removes random data point in the array
     * @throws BagException when bag is empty.
     */

    public void removeRandom() throws BagException {

        //BagException If bag isEmpty() == true
        if(this.isEmpty()){
            throw new BagException("Bag is Empty! Cannot remove.");
        }

        // finding first null value in array
        int fnull = 0;
        while(this.data[fnull] != null){

            if(this.data[99] != null) {
                fnull = 100;
                break;
            }
            fnull++;

        }

        //selecting random index to remove object from using Math.random()
       int remove = (int)(Math.random()*fnull);


        //Special case when removing random from a full bag where there are no null values
        if(fnull == 100){

            int i1 = 0, j1 = 1;
            while (true) {

                //last shift that occurs on indexes 98 and 99
                if((remove + j1) == 99){
                    this.data[98] = this.data[99];
                    this.data[99] = null;
                    break;

                }

                // shifting data values while removing data point
                this.data[remove + i1] = this.data[remove + j1];

                i1++;
                j1++;
            }

            // normal cases with a valid first null index
        }else {

            int i = 0, j = 1;
            while ((remove + j) <= fnull) {
                //shifting values after removal
                this.data[remove + i] = this.data[remove + j];
                i++;
                j++;
            }

        }


    }


}//class