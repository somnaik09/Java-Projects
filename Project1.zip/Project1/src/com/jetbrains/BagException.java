package com.jetbrains;

/*
* Defines an exception that is thrown when program attempts to add to a full bag or remove/obtain from an empty bag
* @author Som Naik
* @version 1.0
 */

public class BagException extends RuntimeException {


    /*
    *Constructs an object with a message
    * @param message A string literal specifying the reason for the exception.
     */

    public BagException(String message){
        super(message);
    }

}