package com.jetbrains;
/*
*Specifications of designing an ADT list
* @author Som Naik
* @version1.0
 */

public interface BagInterface {
/*
* Determines whether array is empty
* @return A boolean value whether list is empty or not
 */

public boolean isEmpty();

/*
* Determines number of items in array
* @return An integer specifying the number of items in array
 */

public int size();

/*
* Adds data point to end of array.
* @param data A reference to the data point added
* @throws BagException If bag is full.
 */

public void insert(Object data) throws BagException;

 /*
 * removes last data point in the array
 * @throws BagException If bag is empty
  */

public void removeLast() throws BagException;

/*
* Removes all data points in the array.
 */

public void makeEmpty();

/*
* Returns data point given index
* @param index Integer specifying position of data
* @throws ListIndexOutOfBoundsException If index < 0 or index >= size()
* @throws BagException If bag is empty. size() = 0
 */

public Object get(int index) throws ListIndexOutOfBoundsException, BagException;

/*
* Retrieves first index of specified Object in the array.
* @param object A reference value for object you want to search
* @throws BagException If bag is empty.
* Locally handles exception when @param (object) is not a String.
 */

public int get(Object object) throws BagException;

/*
* Removes random data point in the array
* @throws BagException when bag is empty.
 */

public void removeRandom() throws BagException; //bag is empty


}// end
