package com.jetbrains;

import java.io.*;
import java.util.Arrays;
import java.util.Scanner;

/*
* Contains helper methods for the array based ADT bag.
* @author Som Naik
* @version 1.0
 */

public class Helper {

    /*
     * Demonstrates and tests the array based ADT bag
     * @throws BagException If bag size is 0 or bag is full.
     * @throws FileNotFoundException If a file is not found.
     * @throws ListIndexOutOfBoundsException If index < 0 or index >= size()
     */

    public static void start() throws FileNotFoundException, ListIndexOutOfBoundsException, BagException {

        //Create and fill bag using create() method
       Bag bag1 = createBag();

       //Displays an array representing the shopping list
        display(bag1);

        //Removes last item and displays bag again
        bag1.removeLast();
        display(bag1);

        //Inserts String st into ADT bag and displays bag
        String st = "Blueberry Pie";
        bag1.insert(st);
        display(bag1);

        //Removes random element from ADT bag and displays bag
        bag1.removeRandom();
        display(bag1);

        //Tests both cases where grocery is in the bag and is not in the bag
        bag1.get("Blueberry Pie");
        System.out.println();
        bag1.get("apple cider");

        //Tests get(index int)
        bag1.get(9);

        //Displays whether bag is empty or not
        System.out.println("This bag is empty: " + bag1.isEmpty());

        //Displays true size of the bag
        System.out.println("The size of this bag: " + bag1.size());

        //Empties ADT bag
        bag1.makeEmpty();
        System.out.println("Bag is now empty.");

        //Verifies that bag is empty
        display(bag1);
        System.out.println("This bag is empty: " + bag1.isEmpty());






    }//method


    /*
     * Creates new Bag object and fills array with data from text file
     * @return A Bag object with a data filled array.
     * @throws FileNotFoundException If a file is not found.
     */

    public static Bag createBag() throws FileNotFoundException {

        //Instantiates new Bag object
        Bag bag1 = new Bag();

        //Creates new File object with @param being specified pathname
        File temp = new File("C:\\Users\\somna\\Desktop\\Project1\\src\\com\\jetbrains\\data.txt");

        //Creates new Scanner object with @param being File object created above^^^
        Scanner scan = new Scanner(temp);


        // scans through text file and loads data into array data field of Bag object
        int i = 0;
        while(scan.hasNext() == true){
            bag1.getData()[i] = scan.nextLine();
            i++;
        }

        //returns Bag object
        return bag1;

    }

    /*
    * Displays array in order aka contents of ADT bag
    * @param bag12 A reference to an ADT bag object
    */

    public static void display(Bag bag12){
        System.out.println(Arrays.toString(bag12.getData()));

    }


}//helper class
