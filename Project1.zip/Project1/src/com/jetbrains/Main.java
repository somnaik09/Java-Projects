package com.jetbrains;

import java.io.*;

/*
* Demonstrates the use of array based ADT bag
* Class initiates start() method from Helper class
* @author Som Naik
* @version 1.0
 */


public class Main {

    /*
     * Tests the array based ADT bag
     * @param args A reference to a String array that stores command-line arguments
     * @throws BagException If bag size is 0 or bag is full.
     * @throws FileNotFoundException If a file is not found.
     * @throws ListIndexOutOfBoundsException If index < 0 or index >= size()
     */

    public static void main(String[] args) throws FileNotFoundException, BagException, ListIndexOutOfBoundsException {

        //start() method tests program
        Helper.start();

    }

}//main class
