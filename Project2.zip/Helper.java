package com.jetbrains;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

/*
 * Contains helper methods for the demonstration of a linked list based String builder.
 * @author Som Naik
 * @version 1.0
 */

public class Helper {

    /*
     * Demonstrates and tests the link list based String builder
     * @throws ListException If the user attempts to retrieve characters on an empty list
     * @throws FileNotFoundException If a file is not found.
     * @throws ListIndexOutOfBoundsException If any index < 0 or index > length() - 1
     */

    public static void start() throws FileNotFoundException, ListIndexOutOfBoundsException, ListException {

        //Creates new ArrayList<> object
        ArrayList<LinkedString> a1 = new ArrayList<>();

        //Calls create() method which fills array list with LinkedString Objects
        create(a1);

        //Call to displayAndMore() method
        displayAndMore(a1);


    }


    /*
     * Fills array list with LinkedString objects created from text file
     * @param a1 A reference to the ArrayList needing to be filled.
     * @throws FileNotFoundException If a file is not found.
     */

    public static void create(ArrayList<LinkedString> a1) throws FileNotFoundException {

        //Creates new File object with @param being specified pathname
        File file = new File("C:\\Users\\somna\\Desktop\\Project2\\src\\com\\jetbrains\\data.txt");

        //Creates new Scanner object with @param being File object created above^^^
        Scanner scan = new Scanner(file);



        //Scans through text file and creates LinkedString objects which are then added to an ArrayList
        int i = 0;
        LinkedString l2;
        while (scan.hasNext()){

            String str = scan.nextLine();
            if(i % 2 == 0) {
                 l2 = new LinkedString(str);
            }
            else{
                 //Some data from text file is passed to the LinkedString constructor as a char[]
                 l2 = new LinkedString(str.toCharArray());
            }

            a1.add(l2);

            i++;
        }

    }

    /*
     * Displays LinkedString objects from filled ArrayList and performs various operations on them
     * @param a1 A reference to an ArrayList on which the operations will be performed
     * @throws FileNotFoundException If a file is not found
     * @throws ListException If user attempts to locate characters in an empty list
     * @throws ListIndexOutOfBoundsException If any index < 0 or index > length() - 1
     */

    public static void displayAndMore(ArrayList<LinkedString> a1) throws FileNotFoundException, ListException, ListIndexOutOfBoundsException {


        //Displays each LinkedString in the array list and displays key characteristics
        int i = 0;
        while (i < a1.size()){

            LinkedString l1 = a1.get(i);

            l1.display();
            System.out.println("Length of List " + (i + 1) + ": " + l1.length());
            System.out.println("List " + (i + 1) + " is empty: " + l1.isEmpty());
            System.out.println("First Character of List " + (i + 1) + ": " + l1.charAt(0));
            l1.substring(0,l1.length() - 1).display();
            System.out.println("^^^Substring starting at first character of List " + (i + 1));
            System.out.println("_______________________________________");

            i++;

        }


        //Concatenates adjacent lists and prints length() of resulting list
        System.out.println("Concatenation\n\n");

        for(int i1 = 0, j1 = 1; j1 < a1.size(); i1++, j1++){

            LinkedString l1 = a1.get(i1).concat(a1.get(j1));

            l1.display();

            System.out.println("Length of combined List: " + l1.length());

            System.out.println("___________________________________");




        }

        System.out.println("Re-displaying all the LinkedString lists to prove that immutability was maintained during operations\n\n");

        i = 0;

        // Re-displays all LinkedString lists to prove immutability
        while (i < a1.size()){

            LinkedString l2 = a1.get(i);

            l2.display();
            System.out.println("Length of List " + (i + 1) + ": " + l2.length());
            System.out.println("List " + (i + 1) + " is empty: " + l2.isEmpty());
            System.out.println("First Character of List " + (i + 1) + ": " + l2.charAt(0));
            l2.substring(0,l2.length() - 1).display();
            System.out.println("^^^Substring starting at first character of List " + (i + 1));
            System.out.println("_______________________________________");

            i++;

        }



    }



}
