package com.jetbrains;

/*
 * Class contains methods for the implementation of a linked list based String builder
 * @author Som Naik
 * @version 1.0
 */


public class LinkedString implements LinkedStringInterface {

    // Data field representing the head of a list
    private Node<Character> head;

    // Data field representing the tail of a list
    private Node<Character> tail;

    // Data field used in counting number of nodes when creating LinkedString list
    private int count = 0;

    // Retrieve reference to the head of a list
    public Node<Character> getHead() {
        return head;
    }

    // Sets reference for the head of a list
    public void setHead(Node<Character> head) {
        this.head = head;
    }

    // Retrieve reference to the tail of a list
    public Node<Character> getTail() {
        return tail;
    }

    // Retrieves count associated with a list
    public int getCount() {
        return count;
    }


    public LinkedString(){

    }

    // LinkedString constructor which passes a char[] to a sister constructor
    // @param st A reference to the string which will be converted to char[]
    public LinkedString(String st){
        this(st.toCharArray());
    }

    // LinkedString constructor which creates lists using char[]
    // @param chars A reference to a char[] that will be used
    public LinkedString(char[] chars){

        // Case for empty list
        if(chars.length == 0){
            this.head = null;
            this.tail = null;

         // Case for one node list
        }else if(chars.length == 1) {

            this.head = new Node<Character>(chars[0],null,null);
            this.tail = this.head;

        }else{

                int i = 0;

                while (i < chars.length) {

                    Node<Character> insert = new Node<>(chars[i]);

                    // Creating head of a list
                    if (this.count == 0) {
                        head = insert;
                        head.setPrevious(null);
                        head.setNext(null);

                    } else {

                        Node<Character> n1 = this.head;

                        while (n1.getNext() != null) {
                            n1 = n1.getNext();
                        }

                        // Inserting other nodes
                        n1.setNext(insert);
                        insert.setPrevious(n1);

                    }

                    i++;
                    count++;


                }

            }
        }

    /*
     * Method displays LinkedString list
     */

    public void display() {

        // Case for empty list
        if(this.head == null){
            System.out.println("");

          // Case for 1 node list
        } else if(this.length() == 1){
            System.out.println(this.getHead().getData());
        }else {


            Node<Character> n1;
            n1 = this.getHead();

            // Printing elements of the list
            while (n1.getNext() != null) {
                System.out.print(n1.getData());
                System.out.print("\t");
                n1 = n1.getNext();
            }

            System.out.print(n1.getData() + "\n");

        }


    }

    /*
     * Method retrieves character from a list at a specified index
     * @param index An integer specifying index of a list
     * @return A character found at specified index
     * @throws ListException If the user attempts to retrieve characters on an empty list
     * @throws ListIndexOutOfBoundsException If any index < 0 or index > length() - 1
     */

    public char charAt(int index) throws ListException, ListIndexOutOfBoundsException{

        if(this.head == null){
            // Exception for locating characters in an empty list
            throw new ListException("Cannot locate characters in an empty list!");
        }

        // Exception for index being out of bounds
        if (index > this.length() -1 || index < 0){
            throw new ListIndexOutOfBoundsException("Index out of bounds!");
        }

        int counter = 0;
        Node<Character> curr;
        curr = head;

        while (counter != index){
            curr = curr.getNext();
            counter++;
        }

        // Returns character value
        return curr.getData();

    }

    /*
     * Method determines whether list is empty or not
     * @return A boolean that details whether the list is empty or not
     */

    public boolean isEmpty(){

        if (this.head == null){
            return true;
        }else
            return false;


    }

    /*
     * Method determines length of the list
     * @return An integer specifying length of the list
     */

    public int length(){

        // Case where list is empty
        if(this.head == null){
            return 0;
        }else {

            int length = 1;
            Node<Character> node = this.head;

            while (node.getNext() != null) {

                node = node.getNext();
                length++;

            }

            return length;
        }
    }

    /*
     * Method retrieves a substring of a list using specified indexes
     * @param start An integer specifying starting index
     * @param end An integer specifying ending index
     * @throws ListIndexOutOfBoundsException If either index is out of range of the list
     * @return A reference to a LinkedString list which contains the substring of the original list
     */

    public LinkedString substring(int start, int end) throws ListIndexOutOfBoundsException{

        // Case for empty list
        if(this.head == null){
            if(start == 0 && end == 0){
                return this;
            }else{
                // Exception for either index being out of bounds
                throw new ListIndexOutOfBoundsException("Index out of bounds!");
            }

        }else if(start < 0 || start > this.length() - 1 || end < 0 || end > this.length() - 1){
            // Exception for either index being out of bounds
            throw new ListIndexOutOfBoundsException("Index out of bounds!");
        }else {

            int counter = 0;

            // Method works with a copy of object to preserve immutability
            LinkedString result = this.replicate();

            Node<Character> node = result.head;

            // Determining start point of list
            while (counter != start) {

                node = node.getNext();
                counter++;

            }

            node.setPrevious(null);
            result.head = node;

            // Determining end point of list
            while (counter != end) {
                node = node.getNext();
                counter++;
            }

            node.setNext(null);
            result.tail = node;


            return result;
        }


    }

    /*
     * Method concatenates two LinkedString lists and returns the result
     * @return A reference to a LinkedString list that contains the concatenation of both lists
     * @param list2 A reference to the second list needing to be concatenated
     */


    public LinkedString concat(LinkedString list2) {

        //Method works with copies of lists to ensure immutability
        LinkedString result1 = this.replicate();

        LinkedString result2 = list2.replicate();

        // Specifying cases where either list is empty
        if (result1.head == null) {
            return result2;
        } else if (result2.head == null) {
            return result1;
        } else if (result1.head == null && result2.head == null) {
            return result1;
        } else {

            Node<Character> listrunner = result1.head;

            while (listrunner.getNext() != null) {
                listrunner = listrunner.getNext();

            }

            listrunner.setNext(result2.head);
            result2.head.setPrevious(listrunner);


            return result1;
        }


    }

    /*
     * Private helper method which creates replicas of LinkedString lists
     * @return A reference to a cloned LinkedString list
     */

    private LinkedString replicate(){

        LinkedString list = new LinkedString();

        // Specifying cases where list is empty or contains 1 node
        if(this.head == null){
            list.head = new Node<Character>(null,null,null);
            return list;
        }else if(this.length() == 1) {

            list.head = new Node<Character>(this.getHead().getData(),null,null);
            return list;

        }else {

                //cloning process
                Node<Character> node = this.getHead();

                Node<Character> listrunner;

                list.head = new Node<Character>(this.getHead().getData(), null, null);
                listrunner = list.head;
                node = node.getNext();

                //cloning nodes into result LinkedString list
                while (node.getNext() != null) {


                    Node node1 = new Node<Character>(node.getData(), null, listrunner);
                    listrunner.setNext(node1);


                    listrunner = listrunner.getNext();
                    node = node.getNext();
                }//while

                Node node1 = new Node<Character>(node.getData(), null, listrunner);
                listrunner.setNext(node1);


                return list;

            }

    }


}//LinkedString
