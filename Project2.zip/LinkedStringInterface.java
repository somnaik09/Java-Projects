package com.jetbrains;

/*
 * Interface contains outline for the implementation of a linked list based String builder
 * @author Som Naik
 * @version 1.0
 */

public interface LinkedStringInterface {

    /*
     * Method displays LinkedString list
     */

    public void display();

    /*
     * Method retrieves character from a list at a specified index
     * @param index An integer specifying index of a list
     * @return A character found at specified index
     * @throws ListException If the user attempts to retrieve characters on an empty list
     * @throws ListIndexOutOfBoundsException If any index < 0 or index > length() - 1
     */

    public char charAt(int index) throws ListException, ListIndexOutOfBoundsException;

    /*
     * Method determines whether list is empty or not
     * @return A boolean that details whether the list is empty or not
     */

    public boolean isEmpty();

    /*
     * Method determines length of the list
     * @return An integer specifying length of the list
     */

    public int length();

    /*
     * Method retrieves a substring of a list using specified indexes
     * @param start An integer specifying starting index
     * @param end An integer specifying ending index
     * @throws ListIndexOutOfBoundsException If either index is out of range of the list
     * @return A reference to a LinkedString list which contains the substring of the original list
     */

    public LinkedString substring(int start, int end) throws ListIndexOutOfBoundsException;

    /*
     * Method concatenates two LinkedString lists and returns the result
     * @return A reference to a LinkedString list that contains the concatenation of both lists
     * @param list2 A reference to the second list needing to be concatenated
     */

    public LinkedString concat(LinkedString list2);

    


}
