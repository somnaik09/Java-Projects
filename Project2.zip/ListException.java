package com.jetbrains;

/*
 * Defines an exception that is thrown when an index is out of bounds.
 * Class extends the RuntimeException class
 * @author Som Naik
 * @version 1.0
 */

public class ListException extends RuntimeException{

    /*
     * Constructs an object with a specific message.
     * @param message A string literal specifying the reason for the exception.
     */

    public ListException(String message){

        super(message);

    }

}



