package com.jetbrains;

/*
 * Defines an exception that is thrown when an index is out of bounds.
 * Class extends the IndexOutOfBoundsException class
 * @author Som Naik
 * @version 1.0
 */

public class ListIndexOutOfBoundsException extends IndexOutOfBoundsException {

    /*
     * Constructs an object with a specific message.
     * @param message A string literal specifying the reason for the exception.
     */

    public ListIndexOutOfBoundsException(String message){
        super(message);
    }

}


