package com.jetbrains;

import java.io.*;

/*
* Demonstrates the use of a linked list based string builder and its methods
* Class initiates start() method from Helper class
* @author Som Naik
* @version 1.0
 */


public class Main {

    /*
     * Tests the linked list based string builder
     * @param args A reference to a String array that stores command-line arguments
     * @throws ListException If the user attempts to retrieve characters on an empty list
     * @throws FileNotFoundException If a file is not found.
     * @throws ListIndexOutOfBoundsException If any index < 0 or index > length() - 1
     */

    public static void main(String[] args) throws FileNotFoundException, ListException, ListIndexOutOfBoundsException {

        //start() method tests program
        Helper.start();


    }

}
