package com.jetbrains;

import java.util.*;

/*
 * Class contains methods for the assessment and evaluation of an infix expression
 * @author Som Naik
 * @version 1.0
 */

public class Expression {

    //Data field representing infix expression
    private String infix;

    //Empty constructor for expression object
    public Expression(){

    }

    /*
     * Constructor which creates expression object with designated infix expression
     * @param infix A reference to a String object which contains the infix expression
    */
    public Expression(String infix){
        this.infix = infix;
    }


    /*
     * Method turns infix String expression into postfix expression
     * @return A reference to an arraylist containing the postfix expression
     */
    public ArrayList<String> infixToPostfix(){

        // Creating new GenericStack object
        GenericStack<String> stack = new GenericStack<>();

        //Creating arraylist to store postfix expression
        ArrayList<String> postfix = new ArrayList<>();

        //Obtaining arraylist of valid tokens from infix expression using toTokens() method
        ArrayList<String> data = this.toTokens();

        for(int i = 0; i < data.size(); i++){

            // token is number
            if(data.get(i).length() > 1 || Character.isDigit(data.get(i).charAt(0))){

                postfix.add(data.get(i));

            // token is + - * /
            }else if (this.isOp(data.get(i))){

                // Appends operators of higher precedence and considers the use of "("
                while (!stack.isEmpty() && !stack.peek().equals("(") && this.hasHigherPrec(stack.peek(),data.get(i))){

                    postfix.add(stack.peek());
                    stack.pop();

                }

                //Pushing current operator
                stack.push(data.get(i));

             //Pushing "("
            }else if(data.get(i).equals("(")){

                stack.push(data.get(i));

            }else if(data.get(i).equals(")")){

                //Adding operations until reaching beginning of parentheses
                while (!stack.isEmpty() && !stack.peek().equals("(")){

                    postfix.add(stack.peek());
                    stack.pop();

                }


                stack.pop();

            }


        }

        //Appending remaining items in the stack to postfix
        while (!stack.isEmpty()){
            postfix.add(stack.peek());
            stack.pop();
        }



        return postfix;

    }

    /*
     * Method returns a reference to an arraylist containing all valid tokens from infix expression
     * @return A reference to an arraylist
     */
    public ArrayList<String> toTokens(){

        //Infix expression
        String st = this.infix;

        ArrayList<String> result = new ArrayList<>();

        int i = 0;

        while (i < st.length()) {

            //Skipping over blank characters
            if(st.charAt(i) == ' ') {
                i++;
                continue;
            }

            //Adding valid one digit and two digit numbers
            if (Character.isDigit(st.charAt(i))) {
                if (i == st.length() - 1) {
                    result.add(st.charAt(i) + "");
                } else {
                    //Two digit numbers
                    if (Character.isDigit(st.charAt(i + 1))) {
                        result.add("" + st.charAt(i) + "" + st.charAt(i + 1));
                        i++;
                    } else {
                        result.add(st.charAt(i) + "");
                    }
                }
            }else {
                result.add(st.charAt(i) + "");
            }

            i++;

        }

        return result;
    }

    /*
     * Method returns the evaluation of a postfix expression
     * @return An integer representing the value of the solved expression
     */

    public int evaluate(){

        ArrayList<String> list = this.infixToPostfix();

        //Creating new stack
        GenericStack<String> stack = new GenericStack<>();

        for(int i = 0; i < list.size(); i++) {

            String token;

            token = list.get(i);

            //Adding all numbers to the stack
            if (this.isOp(token) == false) {

                stack.push(token);

            } else {

                //Peeking into stack to obtain operand 2
                int operand2 = Integer.parseInt(stack.peek());
                stack.pop();

                //Peeking into stack to obtain operand 1
                int operand1 = Integer.parseInt(stack.peek());
                stack.pop();

                //Operating the two operands and pushing result into stack
                stack.push((this.operate(operand1, operand2, token)) + "");


            }


        }

        return Integer.parseInt(stack.peek());
    }

    /*
     * Method determines whether character within a string is an operator or not
     * @param st A reference to a String representing the operator in question
     * @return A boolean representing whether character within a string is an operator or not
     */
    private boolean isOp(String st){

        //Operators cannot be longer than one character
        if (st.length() > 1){
            return false;
        }

        char c = st.charAt(0);

        //Array of operators
        char[] op = {'+','-','/','*'};

        //Scrolling through array of operators to check for a match
        for(char c1 : op){
            if (c == c1){
                return true;
            }

        }

        return false;

    }

    /*
     * Method operates two operands and returns result
     * @param op1 A reference to the first operand
     * @param op2 A reference to the second operand
     * @param token A reference to the operator in string form
     * @return An integer representing value of solved expression
     */

    private int operate(int op1, int op2, String token){

        //Array of operators
        char[] op = {'+','-','/','*'};

        char operator = token.charAt(0);

        //Conducts operation based on operator
        if(operator == op[0])
            return (op1 + op2);
        else if (operator == op[1])
            return (op1 - op2);
        else if (operator == op[2])
            return (op1/op2);
        else if (operator == op[3])
            return (op1 * op2);
        else
            return -1;


    }

    /*
     * Method determines whether an operator has higher precedence than another
     * @param op1 A reference to the first operator
     * @param op2 A reference to the second operator
     * @return A boolean representing whether the first operator has higher precedence than the second
     */

    private boolean hasHigherPrec(String op1, String op2){

        char oper1 = op1.charAt(0);
        char oper2 = op2.charAt(0);

        int opp1;
        int opp2;

        //Precedence values assigned
        if(oper1 == '+' || oper1 == '-'){
            opp1 = 1;
        }else
            opp1 = 2;

        if(oper2 == '+' || oper2 == '-'){
            opp2 = 1;
        }else
            opp2 = 2;

        if(opp1 >= opp2)
            return true;
        else
            return false;


    }


}
