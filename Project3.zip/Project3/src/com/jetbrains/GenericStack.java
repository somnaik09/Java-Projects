package com.jetbrains;

import java.util.*;

/*
 * Class defines the implementation of an array list based stack
 * @author Som Naik
 * @version 1.0
 */

public class GenericStack<E> implements GenericStackInterface<E>{

    //Data field representing array list utilized
    private ArrayList<E> list;

    //Constructor which instantiates new array list
    public GenericStack(){
        list = new ArrayList<>();
    }

    /*
     * Method retrieves size of stack
     * @return An integer representing size of the stack
     */

    public int getSize(){
        return list.size();

    }

    /*
     * Method returns top data value of stack
     * @return A reference to a generic type object representing the top of the stack
     * @throws StackException When attempting to peek into an empty stack
     */

    public E peek() throws StackException{

        //Throws StackException when peeking into empty stack
        if(list.isEmpty())
            throw new StackException("Cannot peek into an empty stack!");
        else
            return list.get(list.size() -1);
    }

    /*
     * Method pushes a data point into the stack
     * @param data A reference to a generic type object representing the data to be pushed onto stack
     */

    public void push(E data) {
        list.add(data);
    }

    /*
     * Method removes the top element of the stack
     * @throws StackException When attempting to remove from an empty stack
     */

    public void pop() throws StackException{
        //Empty stack case
        if(list.isEmpty())
            throw new StackException("Empty Stack! Cannot pop.");
        else
        list.remove(list.size() - 1);
    }

    /*
     * Method returns whether stack is empty or not
     * @return A boolean representing whether stack is empty or not
     */

    public boolean isEmpty(){
        return list.isEmpty();
    }



}//class
