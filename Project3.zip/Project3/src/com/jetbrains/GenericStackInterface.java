package com.jetbrains;

/*
 * Interface contains outline for the implementation of a array list based stack
 * @author Som Naik
 * @version 1.0
 */

public interface GenericStackInterface<E> {

    /*
     * Method retrieves size of stack
     * @return An integer representing size of the stack
     */
    public int getSize();

    /*
     * Method removes the top element of the stack
     * @throws StackException When attempting to remove from an empty stack
     */
    public void pop() throws StackException;

    /*
     * Method returns whether stack is empty or not
     * @return A boolean representing whether stack is empty or not
     */
    public boolean isEmpty();

    /*
     * Method returns top data value of stack
     * @return A reference to a generic type object representing the top of the stack
     * @throws StackException When attempting to peek into an empty stack
     */
    public E peek() throws StackException;

    /*
     * Method pushes a data point into the stack
     * @param data A reference to a generic type object representing the data to be pushed onto stack
     */
    public void push(E data);


}
