package com.jetbrains;

/*
 * Defines an exception that is thrown when attempting to peek into or pop from an empty stack.
 * Class extends the RuntimeException class
 * @author Som Naik
 * @version 1.0
 */

public class StackException extends RuntimeException {

    /*
     * Constructs an object with a specific message.
     * @param message A string literal specifying the reason for the exception.
     */

    public StackException(String message){
        super((message));
    }

}
