package com.jetbrains;

/*
 * Class outlines different data fields in a contact's Address
 * @author Som Naik
 * @version 1.0
 */

public class Address {

    //String representing street
    private String street;

    //String representing city
    private String city;

    //String representing state
    private String state;

    //String representing zipcode
    private String zipcode;


    /*
     * Method returns city of Address
     * @return A reference to a String containing city
     */
    public String getCity() {
        return city;
    }

    /*
     * Method returns state of Address
     * @return A reference to a String containing state
     */

    public String getState() {
        return state;
    }

    /*
     * Method returns street of Address
     * @return A reference to a String containing street
     */

    public String getStreet() {
        return street;
    }

    /*
     * Method returns zipcode of Address
     * @return A reference to a String containing zipcode
     */

    public String getZipcode() {
        return zipcode;
    }


    // Empty constructor
    public Address(){
        this(null,null,null,null);
    }

    /*
     * Constructor initializes Address with specified values
     * @param street A String representing specified street
     * @param city A String representing specified city
     * @param state A String representing specified state
     * @param zipcode A String representing specified zipcode
     */

    public Address(String street, String city, String state, String zipcode){

        this.street = street;
        this.city = city;
        this.state = state;
        this.zipcode = zipcode;

    }

    /*
     * A toString method for an Address
     * @return A String with the contents of the Address
     */

    public String toString(){

        return (street + " " + city + " " + state + " " + zipcode);
    }



}
