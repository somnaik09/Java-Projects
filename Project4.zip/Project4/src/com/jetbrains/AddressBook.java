package com.jetbrains;

/*
 * Class contains methods for the implementation of binary tree based addressbook
 * @author Som Naik
 * @version 1.0
 */

public class AddressBook {

    //Reference to a BinarySearchTree object
    private BinarySearchTree<Contact> tree;

    //Empty Constructor
    public AddressBook(){
        this.tree = new BinarySearchTree<Contact>();
    }

    //Constructor with pre existing tree
    //@param tree A reference to a BinarySearchTree tree
    public AddressBook(BinarySearchTree<Contact> tree){

        this.tree = tree;
    }

    /*
     * Method retrieves reference to the tree associated with addressbook
     * @return A reference to a BonarySearchTree object
     */
    public BinarySearchTree<Contact> getTree() {
        return tree;
    }

    /*
     * Method returns number of contacts in the addressbook
     * @return An integer representing number of contacts
     */
    public int getCount(){

        return tree.getCount();
    }

    /*
     * Method sets specified tree to be the tree of addressbook
     * @param tree A reference to a BinarySearchTree tree
     */
    public void setTree(BinarySearchTree<Contact> tree) {
        this.tree = tree;
    }

    /*
     *Method adds contact to addressbook
     * @param data A reference to the contact to be added
     */

    public void add(Contact data){

        this.tree.add(data);
    }

    /*
     *Method removes contact from addressbook
     * @param data A reference to the contact to be removed
     * @throws TreeException If user attempts to remove from an empty addressbook
     */

    public void remove(Contact data) throws TreeException{

        this.tree.remove(data);
    }

    /*
     * Method tells whether contact exists in addressbook
     * @return A boolean representing whether a contact exists in the addressbook
     */

    public boolean contains(Contact c1){
        return tree.contains(c1);
    }

    /*
     * Method determines whether addressbook is empty
     * @return A boolean representing whether addressbook is empty
     */

    public boolean isEmpty(){

        return this.tree.isEmpty();
    }

    /*
     * Method makes addressbook empty
     */

    public void makeEmpty(){
        tree.makeEmpty();
    }

    /*
     * Method returns reference to a contact
     * searches through contacts using name
     * @param name A String representing the name to be searched
     * @return A reference to a Contact from the addressbook
     */

    public Contact getReference(String name){

        //Creates new contact using name
        Contact c1 = new Contact(name);

        return tree.getReference(c1);
}




}//class
