package com.jetbrains;

/*
 * Interface detailing the methods of a binary search tree based addressbook
 * @author Som Naik
 * @version 1.0
 */

public interface AddressBookInterface {

    /*
     *Method adds contact to addressbook
     * @param data A reference to the contact to be added
     */

    public void add(Contact data);

    /*
     *Method removes contact from addressbook
     * @param data A reference to the contact to be removed
     */

    public void remove(Contact data);

    /*
     * Method tells whether contact exists in addressbook
     * @return A boolean representing whether a contact exists in the addressbook
     */

    public boolean contains(Contact c1);

    /*
     * Method determines whether addressbook is empty
     * @return A boolean representing whether addressbook is empty
     */

    public boolean isEmpty();

    /*
     * Method makes addressbook empty
     */

    public void makeEmpty();


}
