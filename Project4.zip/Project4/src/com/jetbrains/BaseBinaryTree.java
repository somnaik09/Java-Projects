package com.jetbrains;

/*
 * Class outlines basic methods of a binary tree
 * @author Som Naik
 * @version 1.0
 */

public abstract class BaseBinaryTree<T> {

    //TreeNode representing root of the tree
    protected TreeNode<T> root;


    //Empty constructor of a binary tree
    public BaseBinaryTree(){
        root = null;
    }

    //Constructor with set root
    //@param root A reference to the root of a tree
    public BaseBinaryTree(TreeNode<T> root){

        this.root = root;

    }

    /*
     * Method determines whether tree is empty or not
     * @return A boolean representing whether tree is empty or not
     */
    public boolean isEmpty(){
        return this.root == null;
    }

    /*
     * Method empties tree
     */

    public void makeEmpty(){
        this.root = null;
    }

    /*
     * Method returns root of the tree
     * @return A reference to a TreeNode that is the root
     */

    public TreeNode<T> getRoot() {
        if (this.root == null)
            throw new TreeException("Cannot return null root! Empty Tree.");
        else
            return this.root;
    }

    /*
     * Abstract method outlines a method that sets root of a tree
     * @param root A reference to the root of a tree
     */

    public abstract void setRoot(TreeNode<T> root) throws UnsupportedOperationException;



}//class


