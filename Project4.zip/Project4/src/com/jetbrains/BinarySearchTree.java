package com.jetbrains;

/*
 * Class defines methods for the implementation of a binary search tree
 * Class is generic and generic type T extends Comparable interface
 * Class extends BaseBinaryTree class
 * @author Som Naik
 * @version 1.0
 */

public class BinarySearchTree<T extends Comparable<T>> extends BaseBinaryTree<T> {

    //Empty constructor of BinarySearchTree
    public BinarySearchTree(){
        super();
    }

   //Integer representing number of objects in tree
   private int count;

    /*
     * Constructor initializes BinarySearchTree with a specified root
     * @param root A reference to a TreeNode specifying root of tree
     */
    public BinarySearchTree(TreeNode<T> root){
        super(root);
    }

    /*
     * Method throws an Excpetion when user attempts to set root of a tree
     * @param root A reference to a TreeNode to be set as root
     * @throws UnsupportedOperationException when method is invoked
     */

    public void setRoot(TreeNode<T> root) throws UnsupportedOperationException {
            throw new UnsupportedOperationException();
    }

    /*
     * Method returns count of how many objects in the tree
     * @return An int representing how many objects exist in the tree
     */

    public int getCount() {
        return count;
    }

    /*
     * Method adds element to tree if applicable
     * @param contact a reference to the element to be added
     */

    public void add(T contact){

        //Adds data as root is root is null
        if(this.root == null) {
            root = new TreeNode<T>(contact, null, null);
            root.setParent(null);
            count++;
        }// Returns method if element already exists in the tree
        else if(this.contains(contact)){
            System.out.println("Contact name already exists in Address Book!");
            return;
        }else {
            //calls add method
            add(contact, root);
            count++;
        }

    }

    /*
     * Method adds element to the tree
     * @param contact A reference to the element to be added
     * @param current A reference to a TreeNode
     */

    private void add(T contact, TreeNode<T> current){

        //Case where element is less than current node
        if (contact.compareTo(current.getData()) < 0){

            //Case where left child of current is null
            if(current.getLeftChild() == null){

                TreeNode<T> addNode  = new TreeNode<>(contact);

                current.setLeftChild(addNode);

                addNode.setParent(current);

            } else
                //recursive call
                add(contact, current.getLeftChild());

            //Case where element is greater than current node
        } else if(contact.compareTo(current.getData()) > 0){

            //Case where right child of current is null
            if(current.getRightChild() == null){

                TreeNode<T> addNode = new TreeNode<>(contact);

                addNode.setParent(current);

                current.setRightChild(addNode);

            }else {
                //recursive call
                add(contact, current.getRightChild());
            }

        }

    }

    /*
     * Method determines whether an element exists in tree
     * @param data A reference to the element that will be located in the tree
     * @return A boolean specifying whether an element exists in tree
     */

    public boolean contains(T data){

        //TreeNode used for traversal of the tree
        TreeNode<T> runner = this.root;

        while (true) {


            T current = runner.getData();

            //Looks through tree until element is found or no children are left
            if (data.compareTo(current) == 0) {
                return true;
                //Case where element is greater than current element
            } else if (data.compareTo(current) > 0) {
                if (runner.getRightChild() == null) {
                    return false;
                } else
                    runner = runner.getRightChild();
                //Case where element is less than current element
            } else if (data.compareTo(current) < 0) {
                if (runner.getLeftChild() == null) {
                    return false;
                } else
                    runner = runner.getLeftChild();
            }

        }


    }

    /*
     * Method returns a reference to an element in the tree if it exists
     * @param data A reference to the element whose reference in the tree is to be retrieved
     * @return A reference to the desired element in the tree
     */

    public T getReference(T data){

        //Returns null reference if data does not exist in tree
        if(!this.contains(data))
            return null;

            //TreeNode created to traverse the tree
            TreeNode<T> runner = this.root;

            while (true) {

                T current = runner.getData();

                //Case where element is found
                if (data.compareTo(current) == 0) {
                    return current;
                    //Case where element is greater than data in current node
                } else if (data.compareTo(current) > 0) {
                    if (runner.getRightChild() == null) {
                        return null;
                    } else
                        runner = runner.getRightChild();
                    //Case where element is less than data in current node
                } else if (data.compareTo(current) < 0) {
                    if (runner.getLeftChild() == null) {
                        return null;
                    } else
                        runner = runner.getLeftChild();
                }

            }



    }

    /*
     * Method removes specified element from the tree
     * @param data A reference to the element needed to be removed
     * @throws TreeException If attempting to remove from an empty tree
     */

    public void remove(T data) throws TreeException {
        //Cannot remove from an empty tree
        if (root == null)
            throw new TreeException("Cannot remove from Empty Tree!");
        //Cannot remove if object to be removed does not exist
        else if (!this.contains(data)) {
            System.out.println("Object needed to be removed does not exist in tree!");
            return;
        //Case where user attempts to remove tree root with no children
        }else if(count == 1 && this.contains(data)) {
            root = null;
            count = 0;
        }else {
            //TreeNode to traverse to removal point
            TreeNode<T> runner = root;

            //Traversal
            while (true) {

                if (data.compareTo(runner.getData()) == 0) {
                    break;
                } else if (data.compareTo(runner.getData()) > 0) {
                    runner = runner.getRightChild();
                } else if (data.compareTo(runner.getData()) < 0) {
                    runner = runner.getLeftChild();
                }

            }

            //Calls second remove method
            remove(runner);

            count--;

        }
    }

    /*
     * Method removes specified element from the tree
     * @param runner A reference to the node that will be removed
     */

    private void remove(TreeNode<T> runner){

            //Case where node has 0 children
            if(runner.children() == 0){

                TreeNode<T> parent = runner.getParent();

                //Determining which side removal node is on
                if(parent.getData().compareTo(runner.getData()) < 0)
                    parent.setRightChild(null);
                else if(parent.getData().compareTo(runner.getData()) > 0)
                    parent.setLeftChild(null);

                runner.setParent(null);

            //Case where node has one child
            }else if(runner.children() == 1){

                TreeNode<T> parent = runner.getParent();
                TreeNode<T> child;

                //Determining whether is only child is left or right child
                if(runner.getLeftChild() == null)
                    child = runner.getRightChild();
                else
                    child = runner.getLeftChild();


                //Determining which side the removal node is
                if(runner.getData().compareTo(parent.getData()) < 0){
                        child.setParent(parent);
                        parent.setLeftChild(child);
                        runner.setLeftChild(null);
                        runner.setRightChild(null);
                        runner.setParent(null);
                }else if(runner.getData().compareTo(parent.getData()) > 0){
                    child.setParent(parent);
                    parent.setRightChild(child);
                    runner.setRightChild(null);
                    runner.setLeftChild(null);
                    runner.setParent(null);
                }

            //Case where removal node has 2 children
            }else if(runner.children() == 2){

                //TreeNode traverses to lowest node in right subtree of removal node
                TreeNode<T> lowest = searchLowest(runner.getRightChild());

                //copies data from traversal node into removal node
                runner.setData(lowest.getData());

                //removes traversal node recursively
                remove(lowest);

            }


        }

    /*
     * Method searches for the lowest value branch in a subtree
     * @param current A refrence to the node the search will begin on
     * @return A reference to a TreeNode containing the lowest value element in the subtree
     */

    private TreeNode<T> searchLowest(TreeNode<T> current){

        //traverses tree to find lowest value node
        while (current.getLeftChild() != null) {

            current = current.getLeftChild();

        }

        return current;

    }


    /*
     * Method overrides BaseBinaryTree makeEmpty() method
     * New method includes setting count of elements to 0
     */

    @Override
    public void makeEmpty() {
        super.makeEmpty();
        count = 0;
    }

    /*
     * Method instantiates new TreeIterator object
     * @return A reference to a TreeIterator object
     */

    public TreeIterator<T> iterator(){
        return new TreeIterator<>(this);
    }


}//class
