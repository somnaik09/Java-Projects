package com.jetbrains;

/*
 * Class details specifications of a contact to be placed in addressbook
 * Class implements Comparable interface
 * @author Som Naik
 * @version 1.0
 */

public class Contact implements Comparable<Contact> {

    // String representing name
    private String name;

    //Address representing address
    private Address address;

    //String representing phone
    private String phone;

    /*
     * Method returns name of contact
     * @return A String representing the name
     */
    public String getName() {
        return name;
    }

    /*
     * Method sets name of contact
     * @param name A String representing the name to be set
     */

    public void setName(String name) {
        this.name = name;
    }

    /*
     * Method returns address of contact
     * @return A reference to an Address object
     */

    public Address getAddress() {
        return address;
    }

    /*
     * Method returns phone of contact
     * @return A String representing the phone
     */

    public String getPhone() {
        return phone;
    }

    //Empty constructor of Contact
    public Contact(){

    }

    /*
     * Constructor initializes Contact with specified name
     * @param name A String representing specified name
     */
    public Contact(String name){
        this.name = name;
    }

    /*
     * Constructor initializes contact with specified name, address, and phone
     * @param name A String representing specified name
     * @param address A reference to an Address object representing specified address
     * @param phone A String representing specified phone
     */

    public Contact(String name, Address address, String phone){
        this.name = name;
        this.address = address;
        this.phone = phone;

    }

    /*
     * Method compares two Contact objects based on name
     * @param A refrence to a Contact object
     * @return An integer representing the comparison
     */

    public int compareTo(Contact c) {

        String c1 = this.getName();

        String c2 = c.getName();

        //Utilizes String class's compareTo() method
        return c1.compareToIgnoreCase(c2);

    }

    /*
     * Method displays Contact
     */

    public void display() {

        String rename = "";

        //Separates first and last name
        for(int i = 0; i < name.length(); i++){

            if(Character.isUpperCase(name.charAt(i))){
                rename += " ";
            }

            rename += name.charAt(i);
        }



        System.out.println("Name: " + rename + "\nAddress: " + address.toString() + "\nPhone: " + phone);
    }

}
