package com.jetbrains;

import java.io.*;
import java.util.*;

/*
 * Class contains methods to help in the implementation of the binary tree based address book
 * @throws FileNotFound Exception If a file is not found
 * @throws TreeException If a user attempts to remove an item from an empty tree
 * @author Som Naik
 * @version 1.0
 */

public class Helper {

    public static void start() throws FileNotFoundException, TreeException {

        //creates sample contact
        Contact c1 = contactCreator();

        //Initiates new AddressBook
        AddressBook ad = new AddressBook();

        //Demonstrates isEmpty() method
        System.out.println("AddressBook is Empty: " + ad.isEmpty());
        System.out.println("Number of Contacts: " + ad.getCount());
        System.out.println();


        //Fills AddressBook and displays it
        System.out.println("Filling book...");
        System.out.println("Displaying contacts below:\n");
        fillBook(ad);
        display(ad);
        System.out.println("^^^Number of contacts: " + ad.getCount() + "\n\n");


        //Adds new contact and verifies it
        ad.add(c1);
        System.out.println("Contact was added!");
        System.out.println("AddressBook contains added contact: " + ad.contains(c1) + "\n\n");


        //Demonstrates and verifies the use of getReference() method
        Contact c2 = ad.getReference("ChrisBrown");
        System.out.println("Displaying retrieved contact:");
        c2.display();
        System.out.println("\n");

        //Removes contact from list
        ad.remove(c1);
        System.out.println("Contact was removed!");
        System.out.println("Address Book contains removed contact: " + ad.contains(c1) + "\n\n");


        //Empties addressbook
        ad.makeEmpty();
        System.out.println("AddressBook was emptied!");
        System.out.println("AddressBook is Empty: " + ad.isEmpty());
        System.out.println("Number of contacts: " + ad.getCount());


    }

    /*
     * Method creates sample contact to use in start
     * @return A Contact object with specified details
     */

    private static Contact contactCreator(){

        String name = "ChrisBrown";

        String street = "HollyWood Hills";

        String city = "Los Angeles";

        String state = "California";

        String zipcode = "95035";

        String phone = "0345678909876";

        Contact c1 = new Contact(name, new Address(street,city,state,zipcode),phone);

        return c1;

    }

    /*
     * Method fills AddressBook with contacts in a text file
     * @throws FileNotFoundExcpetion If a file is not found
     * @param ad A reference to an addressbook to be filled
     */

    public static void fillBook(AddressBook ad) throws FileNotFoundException {

        //Creates new file object
        File file =  new File("data.txt");

        Scanner scan = new Scanner(file);

        scan.nextLine();

        //Creates ArrayList to store contacts
        ArrayList<Contact> contacts = new ArrayList<>();

        //Creates new contacts and adds into ArrayList
        while (scan.hasNext()) {

            String st = scan.nextLine();

            //Converts Strings to tokens to break into different data fields
            StringTokenizer token = new StringTokenizer(st, "\t", false);

            String fullname = token.nextToken() + token.nextToken();

            String street = token.nextToken();

            String city =  token.nextToken();

            String state = token.nextToken();

            String zipcode = token.nextToken();

            String phone =  token.nextToken();

            Address ad1 = new Address(street,city,state,zipcode);
            Contact c1 = new Contact(fullname, ad1, phone);

            //Adds the new contact
            contacts.add(c1);


        }

        //Creates new BinaryTree to fill with contacts
        BinarySearchTree<Contact> tree = new BinarySearchTree();


        //Adds contacts from ArrayList into binary tree
        while (!contacts.isEmpty()){

            tree.add(contacts.get(0));

            contacts.remove(0);

        }

        //Sets tree datafield of AddressBook
        ad.setTree(tree);


    }

    /*
     * Method displays the contatcts in the addressbook
     * @param ad A reference to the addressbook to be displayed
     */

    public static void display(AddressBook ad){

        //Creates new TreeIterator
        TreeIterator<Contact> it = ad.getTree().iterator();

        //Sets preorder as order of traversal
        it.setPreorder();

        //Displays Contacts in preorder order
        while (it.hasNext()) {
            it.next().display();
            System.out.println("________________________");
        }



    }

}


