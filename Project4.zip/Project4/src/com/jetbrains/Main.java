package com.jetbrains;
import java.io.*;

/*
 * Class demonstrates the use of binary tree based address book
 * @author Som Naik
 * @version 1.0
 */

public class Main {

    /*
     * Method initiates start method which tests binary tree based address book
     * @param args A an array of commands
     * @throws FileNotFoundExcpetion If a file is not found
     * @throws TreeException If usr attempts invalid operation
     */

    public static void main(String[] args) throws FileNotFoundException, TreeException {

        Helper.start();

    }//main method


}//class
