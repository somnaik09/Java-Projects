package com.jetbrains;

import java.util.*;


/*
 * Class defines an Iterator to be used on a binary tree
 * Class implements Iterator interface
 * @author Som Naik
 * @version 1.0
 */

public class TreeIterator<T> implements java.util.Iterator<T> {

    //Data field representing tree
    private BaseBinaryTree<T> tree;

    //Data field representing a LinkedList
    private LinkedList<TreeNode<T>> list;

    /*
     * Constructor initializes TreeIterator given BinaryTree
     * @param tree A reference to a BaseBinaryTree to set the iterator on
     */

    public TreeIterator(BaseBinaryTree<T> tree){
        this.tree = tree;
        this.list = new LinkedList<TreeNode<T>>();

    }

    /*
     * Method returns whether the iterator has a next token
     * @return A boolean representing whether the iterator has a next token
     */

    public boolean hasNext() {
        return !this.list.isEmpty();

    }

    /*
     * Method returns next value in the iterator
     * @return A reference to a data value representing next value in the iterator
     * @throws NoSuchElementException If iterator does not contain next value
     */

    public T next() throws NoSuchElementException{
        return list.remove().getData();
    }

    /*
     * Method removes token from iterator
     * This method is not supported and throws an Exception
     * @throws UnsupportedOperation When method is invoked
     */

    public void remove() throws UnsupportedOperationException{

        throw new UnsupportedOperationException();
    }

    /*
     * Method sets in order traversal for tree
     */

    public void setInorder(){
        list.clear();
        this.inorder(tree.root);
    }

    /*
     * Method traverses tree in inorder and adds elements to list
     * @param node A reference to the TreeNode currently being traversed
     */
    private void inorder(TreeNode<T> node){

        if(node != null){
            inorder(node.getLeftChild());
            list.add(node);
            inorder(node.getRightChild());
        }


    }

    /*
     * Method sets preorder traversal for tree
     */

    public void setPreorder(){
        list.clear();
        this.preorder(tree.root);
    }

    /*
     * Method traverses tree in preorder and adds elements to list
     * @param node A reference to the TreeNode currently being traversed
     */

    private void preorder(TreeNode<T> node){

        if(node != null){
            list.add(node);
            preorder(node.getLeftChild());
            preorder(node.getRightChild());
        }


    }

    /*
     * Method sets postorder traversal for tree
     */

    public void setPostOrder(){
        list.clear();

    }

    /*
     * Method traverses tree in postorder and adds elements to list
     * @param node A reference to the TreeNode currently being traversed
     */

    private void postorder(TreeNode<T> node){

        if(node != null){
            postorder(node.getLeftChild());
            postorder(node.getRightChild());
            list.add(node);
        }


    }


}
