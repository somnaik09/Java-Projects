package com.jetbrains;

/*
 * Class implements a Node structure to be used in a binary tree
 * Class is generic to accept generic type objects
 * @author Som Naik
 * @version 1.0
 */

public class TreeNode<T>  {

    //Generic data type stored in data field
    private T data;

    //Node representing left child of a node
    private TreeNode<T> leftChild;

    //Node representing right child of a node
    private TreeNode<T> rightChild;

    //node representing the parent of a node
    private TreeNode<T> parent;

    //Empty constructor initializing a node
    public TreeNode(){
        this(null,null,null);
    }

    /*Constructor initializing node witth data
     * @param data A reference to the data the node will contain
     */
    public TreeNode(T data){
        this.data = data;
        this.leftChild = null;
        this.rightChild = null;
    }

    /*
     * Constructor initializes node with specified values
     * @param data A reference to the data to be set
     * @param leftChild A reference to the left child node to be set
     * @param rightChild A reference to the right child node to be set
     */

    public TreeNode(T data, TreeNode<T> leftChild, TreeNode<T> rightChild){
            this.data = data;
            this.leftChild = leftChild;
            this.rightChild = rightChild;

    }

    /*
     * Method returns data in the node
     * @return A reference to the data in the node
     */
    public T getData () {
            return data;
    }


    /*
     * Method returns the parent node of current node
     * @return A reference to the parent node of current node
     */

    public TreeNode<T> getParent() {
        return parent;
    }

    /*
     * Method sets parent node of this node
     * @param parent A reference to the node that will be set as parent
     */

    public void setParent(TreeNode<T> parent) {
        this.parent = parent;
    }

    /*
     * Method sets data of the node
     * @param data A reference to the data to be set
     */

    public void setData (T data){
        this.data = data;
    }

    /*
     * Method returns left child node of this node
     * @return A reference to the left child node of this node
     */

    public TreeNode<T> getLeftChild () {
        return leftChild;
    }

    /*
     * Method returns right child node of this node
     * @return A reference to the right child node of this node
     */

    public TreeNode<T> getRightChild () {
        return rightChild;
    }

    /*
     * Method sets left child node of this node
     * @param leftChild A reference to the left child node of this node
     */

    public void setLeftChild (TreeNode < T > leftChild) {
        this.leftChild = leftChild;
    }

    /*
     * Method sets right child node of this node
     * @param rightChildA reference to the right child node of this node
     */

    public void setRightChild (TreeNode < T > rightChild) {
        this.rightChild = rightChild;
    }


    /*
     * Method determines how many children a node has
     * @return An integer representing how many children a node has
     */

    public int children() {
        if (this.getRightChild() == null && this.getLeftChild() == null) {
            return 0;
        } else if (this.getRightChild() == null && this.getLeftChild() != null) {
            return 1;
        }else if(this.getRightChild() != null && this.getLeftChild() == null){
            return 1;
        }else if(this.getRightChild() != null && this.getLeftChild() != null)
            return 2;
        else
            return -1;

    }


}//class

